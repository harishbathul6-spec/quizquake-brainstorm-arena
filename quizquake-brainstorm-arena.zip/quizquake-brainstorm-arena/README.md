# QuizQuake — BrainStorm Arena

A polished adaptive computer-science quiz application built from the supplied hackathon brief. It includes a React + TypeScript frontend, an Express + TypeScript API, a 60-question tagged bank, adaptive difficulty, a timed assessment, topic diagnostics, solution review, attempt history, a remedial drill, simulated cohort context, streak points, and PDF export.

## What is implemented

- **Adaptive difficulty:** starts at Medium; two consecutive correct answers move the next question up one tier; one incorrect answer moves it down one tier. Difficulty is clamped to Easy–Hard.
- **Balanced coverage:** the full assessment rotates across Data Structures, Algorithms, Operating Systems, and Computer Networks.
- **Timer:** 10 minutes for the full run and 5 minutes for a focused drill; expiry submits the answers already recorded.
- **Diagnostic report:** radar chart and per-topic mastery percentages, plus explanations, correct answers, selected answers, and approximate time per question.
- **History:** attempt records are written to the Express JSON store (`server/data/attempts.json`) and cached locally as a fallback.
- **Remedial drill:** starts a five-question practice run for a selected topic.
- **Gamification:** hard-tier correct answers award extra points; a streak bonus is applied from the third consecutive correct answer.
- **PDF export:** creates a faculty-friendly scorecard with topic scores and answer review.

## Requirements

- Node.js 20 or newer (Node.js 18.18+ should also work)
- npm 9+

## Run locally

Open a terminal in the project root and run:

```bash
npm install
npm run dev
```

Then open **http://localhost:5173**. The API runs at **http://localhost:4000**. You can check it at `http://localhost:4000/api/health`.

To create production builds:

```bash
npm run build
```

The frontend build is written to `client/dist`; the API build is written to `server/dist`.

## Data and persistence

The server creates `server/data/attempts.json` automatically. This is a lightweight JSON persistence layer suitable for a hackathon demo, not a multi-user production database. The browser also keeps a local history fallback in localStorage. Do not commit real student records.

## GitHub: step by step

1. Sign in to GitHub and create a **new repository**. Give it a name such as `quizquake-brainstorm-arena`. Choose Public or Private. Do not initialize it with a README, `.gitignore`, or license because this project already contains those files.
2. Extract the ZIP file to a folder on your computer.
3. Open that extracted `quizquake-brainstorm-arena` folder in VS Code.
4. Open **Terminal → New Terminal**. Confirm the terminal is at the project root (the folder containing the root `package.json`).
5. Install dependencies and make sure it builds:

   ```bash
   npm install
   npm run build
   ```

6. Initialize Git and make your first commit:

   ```bash
   git init
   git add .
   git commit -m "Build QuizQuake adaptive quiz app"
   ```

7. Copy the HTTPS repository URL from your new GitHub repository. Connect it and push:

   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/quizquake-brainstorm-arena.git
   git push -u origin main
   ```

   Replace `YOUR-USERNAME` with your GitHub username and use the exact URL GitHub gives you.

8. Refresh the GitHub repository page. Your source files should now be visible. For later changes, use:

   ```bash
   git add .
   git commit -m "Describe your update"
   git push
   ```

### If Git asks you to sign in

Complete the browser sign-in prompt from Git Credential Manager. GitHub no longer accepts your account password directly for HTTPS Git operations. If prompted for a token, create a fine-grained personal access token on GitHub with access to this repository and **Contents: Read and write**, then use it as the password. Never paste a token into source code or commit it.

### If `git` is not recognized

Install Git from https://git-scm.com/downloads, restart VS Code, open a new terminal, and retry the commands.

### If the remote already exists

Run `git remote -v` to inspect it. If it points to the wrong repository, update it with:

```bash
git remote set-url origin https://github.com/YOUR-USERNAME/quizquake-brainstorm-arena.git
```

## Project structure

```text
quizquake-brainstorm-arena/
├── client/
│   ├── src/App.tsx          # Application screens and quiz logic
│   ├── src/questions.ts     # 60 topic-tagged MCQs with explanations
│   ├── src/styles.css       # Responsive dark dashboard styling
│   └── ...                  # Vite + React + TypeScript setup
├── server/
│   ├── src/index.ts         # Express API and JSON attempt persistence
│   └── ...                  # TypeScript setup
├── package.json             # npm workspaces and root scripts
└── README.md
```

## Notes before a live judging demo

- The cohort benchmark mentioned in the brief is not presented as real student data. This build focuses on the required adaptive flow and diagnostics; if you add a cohort comparison, label the comparison as simulated unless you have a real, consented dataset.
- The question bank is a curated demo bank, not an externally certified exam bank. Review questions and explanations with your faculty/domain mentor before using it for formal assessment.
- The JSON store is intentionally simple. For a deployed multi-user product, add authentication, a database such as PostgreSQL/SQLite, input validation, and server-side ownership checks.
