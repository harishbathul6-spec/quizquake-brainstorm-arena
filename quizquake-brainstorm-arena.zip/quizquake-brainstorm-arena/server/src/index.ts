import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
const app=express(); app.use(cors()); app.use(express.json({limit:'1mb'}));
const here=path.dirname(fileURLToPath(import.meta.url));
const dataDir=path.resolve(here,'../data'); const dbFile=path.join(dataDir,'attempts.json');
fs.mkdirSync(dataDir,{recursive:true}); if(!fs.existsSync(dbFile)) fs.writeFileSync(dbFile,'[]');
function read(){try{return JSON.parse(fs.readFileSync(dbFile,'utf8')) as any[]}catch{return []}}
function write(rows:any[]){fs.writeFileSync(dbFile,JSON.stringify(rows,null,2))}
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'QuizQuake API',version:'1.0.0'}));
app.get('/api/attempts',(_req,res)=>res.json(read().slice().reverse()));
app.post('/api/attempts',(req,res)=>{const body=req.body;if(!body||typeof body.score!=='number'||!Array.isArray(body.answers)){return res.status(400).json({error:'Invalid attempt payload'});}const row={id:randomUUID(),createdAt:new Date().toISOString(),...body};const rows=read();rows.push(row);write(rows);res.status(201).json(row)});
app.delete('/api/attempts',(req,res)=>{if(req.query.confirm!=='yes')return res.status(400).json({error:'Pass confirm=yes to clear history'});write([]);res.json({ok:true})});
const port=Number(process.env.PORT)||4000; app.listen(port,()=>console.log(`QuizQuake API running at http://localhost:${port}`));
